#!/usr/bin/python
#config file containing credentials for rds aurora instance
db_username = "demouser"
db_password = "password"
db_name = "lambdademo"
db_endpoint = "lambda-demo.cluster-cjgaan5hgqwo.us-east-1.rds.amazonaws.com"
